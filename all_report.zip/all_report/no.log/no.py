# -*- encoding=utf8 -*-
__author__ = "esunmoda"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
ST.OPDELAY = 3
ST.THRESHOLD = 0.9
if not cli_setup():
    auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/NCAIB7000449YV8?cap_method=MINICAP&touch_method=MAXTOUCH&",])



# script content
print("start...")
try:
    touch(Template(r"tpl1690266165235.png", record_pos=(-0.12, 0.343), resolution=(1080, 2400)))
    touch(Template(r"tpl1690266171768.png", record_pos=(-0.394, -0.82), resolution=(1080, 2400)))


except Exception as e:
    log(e,snapshot=True)

finally:
    # generate html report
    #from airtest.report.report import simple_report
    #simple_report(__file__,logpath=True)
    from airtest.report.report import LogToHtml
    h1 = LogToHtml(static_root=r"/Users/esunmoda/Desktop/static_root",export_dir=r"/Users/esunmoda/Desktop/all_report",lang="zh",
                  plugins=["poco.utils.airtest.report"],script_root=r"/Users/esunmoda/Desktop/no/no.py")
    h1.report()