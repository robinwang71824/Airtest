# -*- encoding=utf8 -*-
__author__ = "esunmoda"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
ST.OPDELAY = 3
ST.THRESHOLD = 0.9
if not cli_setup():
    auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/NCAIB7000449YV8?cap_method=MINICAP&touch_method=MAXTOUCH&",])

from poco.drivers.android.uiautomation import AndroidUiautomationPoco
poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)

# script content
print("start...")
try:
    touch(Template(r"tpl1690428477520.png", record_pos=(-0.309, -0.619), resolution=(1080, 2400)))
 
    poco("android.widget.FrameLayout").child("android.widget.LinearLayout").child("android.widget.FrameLayout").offspring("android:id/content").child("android.view.ViewGroup").child("com.esunsec.etrade:id/")[2].child("android.view.ViewGroup").child("com.esunsec.etrade:id/")[0].set_text("A128437686")
    poco("android.widget.FrameLayout").child("android.widget.LinearLayout").child("android.widget.FrameLayout").offspring("android:id/content").child("android.view.ViewGroup").child("com.esunsec.etrade:id/")[2].child("android.view.ViewGroup").child("com.esunsec.etrade:id/")[4].set_text("abc123")   
    poco("android.widget.FrameLayout").child("android.widget.LinearLayout").child("android.widget.FrameLayout").offspring("android:id/content").child("android.view.ViewGroup").child("com.esunsec.etrade:id/")[2].child("android.view.ViewGroup").child("com.esunsec.etrade:id/")[6].click()
    touch(Template(r"tpl1690428283034.png", record_pos=(-0.001, 0.601), resolution=(1080, 2400)))
    sleep(3)
    touch(Template(r"tpl1690428298333.png", record_pos=(-0.374, 0.575), resolution=(1080, 2400)))
    touch(Template(r"tpl1690428315589.png", record_pos=(0.003, 0.966), resolution=(1080, 2400)))
    touch(Template(r"tpl1690428326919.png", record_pos=(0.001, 0.197), resolution=(1080, 2400)))
    sleep(3)
    if not exists(Template(r"tpl1690428372856.png", record_pos=(-0.238, -0.455), resolution=(1080, 2400))):
        raise Exception("身分證非記住id登入有誤")


except Exception as e:
    log(e,snapshot=True)

finally:
    # generate html report
    from airtest.report.report import simple_report
    simple_report(__file__,logpath=True)

