# -*- encoding=utf8 -*-
__author__ = "esunmoda"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
ST.OPDELAY = 3
ST.THRESHOLD = 0.9
if not cli_setup():
    auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/NCAIB7000449YV8?cap_method=MINICAP&touch_method=MAXTOUCH&",])
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)
import os

# script content
print("start...")

def run_script():
    try:
        #f = open('password.txt')
        #password = f.read()
        #f.close()
        currdir=os.path.dirname(__file__)
        password_path=os.path.join(currdir,'..','password.txt')
        with open(password_path,'r') as f:
            password = f.read()

        poco("com.esun:id/et_show_mp").set_text(password)

        touch(Template(r"tpl1690873077664.png", record_pos=(-0.288, -0.155), resolution=(1080, 2400)))
        sleep(3)

        if exists(Template(r"tpl1690873099839.png", record_pos=(-0.381, -0.956), resolution=(1080, 2400))):
            touch(Template(r"tpl1690873099839.png", record_pos=(-0.381, -0.956), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873133201.png", record_pos=(-0.001, 0.381), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873145137.png", record_pos=(0.008, -0.578), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873159402.png", record_pos=(0.405, -0.793), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873170952.png", record_pos=(0.116, -0.844), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873181033.png", record_pos=(-0.38, -0.281), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873195555.png", record_pos=(-0.088, -0.706), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873215689.png", record_pos=(0.358, -0.245), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873224470.png", record_pos=(0.34, 0.194), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873237695.png", record_pos=(-0.206, -0.095), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873248999.png", record_pos=(-0.242, 0.99), resolution=(1080, 2400)))
        touch(Template(r"tpl1690873267756.png", record_pos=(-0.204, 0.366), resolution=(1080, 2400)))
        poco("android.widget.FrameLayout").offspring("android:id/content").offspring("com.esun:id/et_show_mp").set_text(password)
        touch(Template(r"tpl1690960004918.png", record_pos=(0.319, 0.005), resolution=(1080, 2400)))
        touch(Template(r"tpl1690960011329.png", record_pos=(-0.195, 0.18), resolution=(1080, 2400)))
        #sleep(5)
        #touch(Template(r"tpl1690960105139.png", record_pos=(0.4, -0.391), resolution=(1080, 2400)))


    except Exception as e:
        log(e,snapshot=True)

    finally:
        # generate html report
        #from airtest.report.report import simple_report
        #simple_report(__file__,logpath=True)

        from airtest.report.report import LogToHtml
        r = LogToHtml(script_root=r"/Users/esunmoda/Desktop/A+/test_1_1/1_1.py",export_dir=r"/Users/esunmoda/Desktop/A+",lang="zh",plugins=["poco.utils.airtest.report"])
        r.report()

def build_zip():
    import shutil
    shutil.make_archive('A+_report','zip','/Users/esunmoda/Desktop/A+/1_1')

def upload_github():
    from github import Github
    username="robinwang71824"
    password="Wanwan1995"
    token="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"
    g=Github(token)
    repo=g.get_repo("robinwang71824/Airtest")
    with open("A+_report.zip","rb") as file:
        data = file.read()
    repo.create_file("A+_report.zip","upload report",data,branch="main")
    
def send_email():
    import email.message
    from datetime import datetime
    #建立email訊息物件
    msg=email.message.EmailMessage()

    today=datetime.today().strftime("%Y-%m-%d")

    #利用物件建立基本設定
    msg["From"]="rjgwang1995@gmail.com"
    #msg["To"]="senwang-71039@esunsec.com.tw,robinwang-71824@esunsec.com.tw,ronwu-71230@esunsec.com.tw"
    msg["To"]="robinwang-71824@esunsec.com.tw"
    msg["Subject"]=today + "測試結果"

    #輸入寄送郵件主要內容
    #msg.add_alternative("<h3>HTML內容</h3>安安這是寄送郵件測試",subtype="html") #HTML信件內容
    msg.set_content( today + "測試報告已完成，欲查看報告請點選連結" + "\nhttps://github.com/robinwang71824/Airtest")

    #連線到SMTP Sevver
    acc="rjgwang1995@gmail.com"
    password="thbmucoarikbyxlf"

    import smtplib
    server=smtplib.SMTP_SSL("smtp.gmail.com",465) #建立gmail連線
    server.login(acc,password)
    server.send_message(msg)
    #發送完成後關閉連線
    server.close()

def line_notify(time):
    import requests
    token = 'QXogxn6zgRQlh7k7JQj5JdwO5XpRPliKvPLENDkBNUv'
    headers = {"Authorization": "Bearer " + token,}
    payload = {'message': "\n" + time + " Android_A+完成測試:\n共Ｎ項，完成Ｎ項"}
    r = requests.post("https://notify-api.line.me/api/notify", headers = headers, params = payload)
    print(r.status_code)
    return r.status_code
    
if __name__ == '__main__':
    from datetime import datetime
    run_script()
    time = datetime.today().strftime("%Y-%m-%d %H:%M:%S")
    #build_zip()
    #upload_github()
    #send_email()
    #line_notify(time)
        
        
