# -*- encoding=utf8 -*-
__author__ = "esunmoda"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
ST.OPDELAY = 3
ST.THRESHOLD = 0.9
if not cli_setup():
    auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/NCAIB7000449YV8?cap_method=MINICAP&touch_method=MAXTOUCH&",])



# script content
print("start...")
try:
    touch(Template(r"/Users/esunmoda/Desktop/yes/yes1.png"))
    touch(Template(r"/Users/esunmoda/Desktop/yes/yes2.png"))
    

except Exception as e:
    log(e,snapshot=True)

finally:
    # generate html report
    from airtest.report.report import simple_report
    simple_report(__file__,logpath=True)

